# 🏠 Real Estate Market Analyzer

Analyze real estate listings using web scraping, machine learning, and interactive dashboards.

## Features
- Scrapes property data (price, location, size, etc.)
- Predicts house prices using regression
- Flags underpriced listings
- Interactive Streamlit dashboard

## Folder Structure
- `scraper/`: Scraping logic
- `data/`: Raw and processed data
- `model/`: ML model training and prediction
- `dashboard/`: Interactive app (Streamlit)
- `utils/`: Helper functions for preprocessing

## Run Dashboard
```bash
cd dashboard
streamlit run app.py
```