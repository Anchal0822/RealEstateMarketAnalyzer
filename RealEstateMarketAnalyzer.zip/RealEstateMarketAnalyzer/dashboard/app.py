import streamlit as st
import pandas as pd
import plotly.express as px

df = pd.read_csv('../data/raw_listings.csv')
df['Price_per_sqft'] = df['Price'] / df['Size (sqft)']

st.title("🏠 Real Estate Market Analyzer")

location = st.selectbox("Select a Location", df['Location'].unique())
filtered = df[df['Location'] == location]

st.plotly_chart(px.histogram(filtered, x='Price', nbins=20, title=f'Price Distribution in {location}'))

avg_per_sqft = df.groupby('Location')['Price_per_sqft'].mean().to_dict()
df['Underpriced'] = df.apply(lambda x: x['Price_per_sqft'] < 0.85 * avg_per_sqft[x['Location']], axis=1)

st.subheader("💰 Underpriced Listings")
st.dataframe(df[df['Underpriced'] == True][['Title', 'Location', 'Price', 'Size (sqft)', 'Price_per_sqft']])