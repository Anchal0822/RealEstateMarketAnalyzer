import requests
from bs4 import BeautifulSoup
import pandas as pd

def scrape_properties():
    url = 'https://example.com/properties'
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')

    listings = []
    for item in soup.select('.property-card'):
        title = item.select_one('.title').text.strip()
        price = float(item.select_one('.price').text.strip().replace('₹','').replace(',',''))
        size = float(item.select_one('.size').text.strip().split()[0])
        location = item.select_one('.location').text.strip()

        listings.append({
            'Title': title,
            'Price': price,
            'Size (sqft)': size,
            'Location': location
        })

    df = pd.DataFrame(listings)
    df.to_csv('../data/raw_listings.csv', index=False)
    print("Scraped and saved to raw_listings.csv")

if __name__ == "__main__":
    scrape_properties()