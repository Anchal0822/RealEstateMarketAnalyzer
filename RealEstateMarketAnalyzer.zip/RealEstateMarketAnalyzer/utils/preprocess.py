import pandas as pd

def clean_and_engineer(df):
    df['Price_per_sqft'] = df['Price'] / df['Size (sqft)']
    df = pd.get_dummies(df, columns=['Location'])
    return df